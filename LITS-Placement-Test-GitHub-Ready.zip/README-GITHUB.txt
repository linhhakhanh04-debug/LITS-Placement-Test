LITS Placement Test - GitHub Pages ready

Upload the CONTENTS of this folder to the root of your GitHub repository.
Required root files include index.html, styles.css, app.js, superkids.html, superkids.css, superkids.js and the assets folder.

GitHub Pages settings:
Settings > Pages > Deploy from a branch > main > /(root) > Save

Note: Teacher History currently uses browser localStorage, so results are stored only on the device/browser where the test is completed.
